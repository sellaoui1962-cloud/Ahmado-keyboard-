package com.kimikb.keyboard

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private lateinit var prefs: SharedPreferences

    private val teal = 0xFF00897B.toInt()
    private val ink = 0xFF1F2328.toInt()
    private val grey = 0xFF6B7280.toInt()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundBg(fill: Int, r: Int, stroke: Int = 0, strokeColor: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(r).toFloat()
        if (stroke > 0) g.setStroke(stroke, strokeColor)
        return g
    }

    private fun card(parent: LinearLayout, title: String?): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = roundBg(Color.WHITE, 16)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 0, dp(12))
        parent.addView(c, lp)
        if (title != null) {
            val tv = TextView(this)
            tv.text = title
            tv.textSize = 17f
            tv.setTextColor(teal)
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.setPadding(0, 0, 0, dp(8))
            c.addView(tv)
        }
        return c
    }

    private fun note(parent: LinearLayout, t: String) {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 13f
        tv.setTextColor(grey)
        tv.setPadding(0, dp(2), 0, dp(6))
        parent.addView(tv)
    }

    private fun switchRow(parent: LinearLayout, title: String, sub: String?, key: String, def: Boolean) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(6), 0, dp(6))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.text = title
        t.textSize = 16f
        t.setTextColor(ink)
        col.addView(t)
        if (sub != null) {
            val s = TextView(this)
            s.text = sub
            s.textSize = 12.5f
            s.setTextColor(grey)
            col.addView(s)
        }
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this)
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply() }
        row.addView(sw)
        parent.addView(row)
    }

    private fun addButton(parent: LinearLayout, text: String, filled: Boolean, onClick: () -> Unit) {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(if (filled) Color.WHITE else teal)
        b.background = roundBg(if (filled) teal else 0xFFE0F2F1.toInt(), 12)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(6)
        parent.addView(b, lp)
    }

    private fun divider(parent: LinearLayout) {
        val v = View(this)
        v.setBackgroundColor(0x22888888)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 2)
        lp.setMargins(0, dp(8), 0, dp(8))
        parent.addView(v, lp)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("kb_prefs", MODE_PRIVATE)
        title = "إعدادات كيبوردي"

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setPadding(dp(14), dp(18), dp(14), dp(24))
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(0xFFF1F4F8.toInt())
        scroll.addView(root)
        setContentView(scroll)

        // ---- header
        val h1 = TextView(this)
        h1.text = "⌨️ كيبوردي"
        h1.textSize = 28f
        h1.setTextColor(ink)
        h1.typeface = Typeface.DEFAULT_BOLD
        h1.setPadding(dp(4), dp(4), dp(4), 0)
        root.addView(h1)
        val h2 = TextView(this)
        h2.text = "عربية • Français • حافظة ذكية • ثيمات"
        h2.textSize = 14f
        h2.setTextColor(grey)
        h2.setPadding(dp(4), 0, dp(4), dp(14))
        root.addView(h2)

        // ---- quick start
        val setup = card(root, "🚀 البدء السريع")
        note(setup, "فعّل «كيبوردي» ثم اخترها كلوحة المفاتيح الحالية.")
        addButton(setup, "١) تفعيل الكيبورد", true) {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        addButton(setup, "٢) اختيار الكيبورد", false) {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        val tryBox = EditText(this)
        tryBox.hint = "✏️ جرّب الكتابة هنا"
        tryBox.background = roundBg(0xFFF1F4F8.toInt(), 12)
        tryBox.setPadding(dp(12), dp(10), dp(12), dp(10))
        val tlp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tlp.topMargin = dp(10)
        setup.addView(tryBox, tlp)

        // ---- themes
        val themeCard = card(root, "🎨 الثيم")
        val swRow = LinearLayout(this)
        swRow.orientation = LinearLayout.HORIZONTAL
        val swViews = mutableListOf<TextView>()
        fun paintSwatches() {
            val cur = prefs.getInt("theme", 1)
            for ((i, tv) in swViews.withIndex()) {
                val p = Themes.get(i)
                tv.background = if (i == cur) roundBg(p.bg, 12, dp(3), p.special)
                else roundBg(p.bg, 12, dp(1), 0x44888888)
            }
        }
        for (i in 0 until Themes.COUNT) {
            val p = Themes.get(i)
            val tv = TextView(this)
            tv.text = Themes.names[i]
            tv.textSize = 13f
            tv.gravity = Gravity.CENTER
            tv.setTextColor(p.text)
            tv.setPadding(dp(4), dp(20), dp(4), dp(20))
            tv.setOnClickListener {
                prefs.edit().putInt("theme", i).apply()
                paintSwatches()
            }
            swViews.add(tv)
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), 0, dp(3), 0)
            swRow.addView(tv, lp)
        }
        themeCard.addView(swRow)
        paintSwatches()
        note(themeCard, "نقر مطوّل على ⚙ في شريط الاقتراحات يبدّل الثيم بسرعة.")

        // ---- clipboard
        val clipCard = card(root, "📋 الحافظة")
        switchRow(clipCard, "حفظ سجل الحافظة", "كل نص تنسخه يظهر في زر 📋 أعلى الكيبورد", "clip_enabled", true)
        note(clipCard, "يُحفظ السجل على جهازك فقط. النصوص التي تضع عليها التطبيقات علامة «حساس» (كلمات المرور) لا تُحفظ. ثبّت عنصراً بـ 📌 ليبقى دائماً.")
        addButton(clipCard, "🗑 مسح سجل الحافظة (بما فيه المثبّت)", false) {
            ClipboardStore(this).clearAll()
            Toast.makeText(this, "تم المسح ✓", Toast.LENGTH_SHORT).show()
        }

        // ---- typing
        val typing = card(root, "⌨️ الكتابة")
        switchRow(typing, "🔊 الصوت عند الكتابة", null, "sound", true)
        switchRow(typing, "📳 الاهتزاز عند الضغط", null, "vibrate", true)
        switchRow(typing, "🔤 رموز التلميح على الحروف",
            "أرقام صغيرة في زاوية المفاتيح ورموز الحروف البديلة", "hints", true)
        switchRow(typing, "🔠 الكتابة المنفصلة (تهجئة)", "احمد ← أ ح م د", "separate", false)

        val langCard = card(root, "🌍 اللغة الافتراضية")
        val groupLang = RadioGroup(this)
        val langs = arrayOf("العربية", "Français")
        for (i in langs.indices) {
            val rb = RadioButton(this)
            rb.text = langs[i]
            rb.textSize = 16f
            rb.id = View.generateViewId()
            rb.tag = i
            rb.isChecked = prefs.getInt("default_lang", 0) == i
            groupLang.addView(rb)
        }
        groupLang.setOnCheckedChangeListener { g, id ->
            val btn = g.findViewById<RadioButton>(id)
            if (btn != null) prefs.edit().putInt("default_lang", btn.tag as Int).apply()
        }
        langCard.addView(groupLang)

        // ---- dictionary
        val dict = card(root, "🧠 القاموس الشخصي")
        val learnedCount = prefs.getStringSet("learned", emptySet())?.size ?: 0
        note(dict, "الكلمات المتعلّمة: $learnedCount")
        addButton(dict, "مسح الكلمات المتعلّمة", false) {
            prefs.edit().remove("learned").apply()
            Toast.makeText(this, "تم المسح ✓", Toast.LENGTH_SHORT).show()
            recreate()
        }

        // ---- shortcuts
        val sc = card(root, "⚡ الاختصارات")
        note(sc, "اكتب الاختصار + مسافة ← يظهر النص الكامل. مثال: «سلام» ← «السلام عليكم ورحمة الله وبركاته»")
        val etT = EditText(this)
        etT.hint = "الاختصار (مثال: سلام)"
        val etE = EditText(this)
        etE.hint = "النص الكامل"
        sc.addView(etT)
        sc.addView(etE)
        addButton(sc, "➕ إضافة اختصار", true) {
            val t = etT.text.toString().trim()
            val e = etE.text.toString().trim()
            if (t.isNotEmpty() && e.isNotEmpty()) {
                val set = (prefs.getStringSet("shortcuts", emptySet()) ?: emptySet()).toMutableSet()
                set.removeAll { it.startsWith("$t=") }
                set.add("$t=$e")
                prefs.edit().putStringSet("shortcuts", set).apply()
                Toast.makeText(this, "تمت الإضافة ✓", Toast.LENGTH_SHORT).show()
                recreate()
            }
        }
        val existing = (prefs.getStringSet("shortcuts", emptySet()) ?: emptySet()).sorted()
        for (raw in existing) {
            val i = raw.indexOf('=')
            if (i < 0) continue
            divider(sc)
            val rowL = LinearLayout(this)
            rowL.orientation = LinearLayout.HORIZONTAL
            rowL.gravity = Gravity.CENTER_VERTICAL
            val tv = TextView(this)
            tv.text = "${raw.substring(0, i)}  ←  ${raw.substring(i + 1)}"
            tv.textSize = 14f
            tv.setTextColor(ink)
            rowL.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val del = TextView(this)
            del.text = "✕"
            del.textSize = 18f
            del.setTextColor(grey)
            del.setPadding(dp(12), dp(6), dp(12), dp(6))
            del.setOnClickListener {
                val set = (prefs.getStringSet("shortcuts", emptySet()) ?: emptySet()).toMutableSet()
                set.remove(raw)
                prefs.edit().putStringSet("shortcuts", set).apply()
                recreate()
            }
            rowL.addView(del)
            sc.addView(rowL)
        }
    }
}
