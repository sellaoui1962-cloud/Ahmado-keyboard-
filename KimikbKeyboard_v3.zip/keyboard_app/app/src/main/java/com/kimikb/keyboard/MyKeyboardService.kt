package com.kimikb.keyboard

import android.content.ClipboardManager
import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Vibrator
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MyKeyboardService : InputMethodService(), KeyboardView.Listener {

    enum class Page { AR, FR, NUM, NUMPAD, SYM, EMOJI }

    private lateinit var prefs: SharedPreferences
    private lateinit var container: LinearLayout
    private lateinit var candidateBar: LinearLayout
    private lateinit var kv: KeyboardView

    private var page = Page.AR
    private var lastAlpha = Page.AR
    private var shift = false
    private var capsLock = false

    private val arWords = ("في من على إلى عن هذا ذلك الذي التي ما لا لم لن قد كان يكون مع هو هي نحن أنا أنت أنتم هم هن " +
        "فيه منه عليه عليها عند بعد قبل بين كل بعض غير أي أو ثم كما لكن لأن لذلك حتى إذا كيف لماذا أين متى أيضا " +
        "جدا الآن هنا هناك اليوم غدا أمس أريد أحب أعمل أذهب تعال اكتب إقرأ اسم كتاب ماء خبز بيت ولد بنت صباح " +
        "مساء ليل نهار شمس قمر وقت سنة أسبوع جميل كبير صغير جديد طويل قصير جيد سيء حار بارد سريع بطيء").split(" ")

    private val frWords = ("le la les des une un et est dans pour avec qui que sur pas plus moi vous tu il elle nous " +
        "sont été faire pourquoi comment quand où aussi très bien merci beaucoup aujourd'hui demain hier maison " +
        "eau pain livre garçon fille soleil lune chat chien voiture travail école ami famille bonjour bonsoir " +
        "salut oui non voilà temps année semaine jour monde pays ville grand petit nouveau beau bon mauvais").split(" ")

    // ---------------- lifecycle ----------------

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("kb_prefs", MODE_PRIVATE)
        clipStore = ClipboardStore(this)
        clipManager = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipManager.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        if (::clipManager.isInitialized) clipManager.removePrimaryClipChangedListener(clipListener)
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        prefs = getSharedPreferences("kb_prefs", MODE_PRIVATE)
        container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        candidateBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        kv = KeyboardView(this)
        kv.listener = this
        // spelling-game category bar: pick ONE or MORE categories (or ALL)
        catLabel = TextView(this).apply {
            textSize = 14f
            visibility = View.GONE
            val p = (resources.displayMetrics.density * 14).toInt()
            setPadding(p, 10, p, 10)
        }
        // 8 chips do not fit in one row -> two rows of 4
        val chipsRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chipsRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val allKeys = catNames.keys.toList() + ALL_KEY
        allKeys.forEachIndexed { i, key ->
            val name = if (key == ALL_KEY) "✨ الكل" else catNames[key]!!
            val chip = TextView(this).apply {
                text = name
                textSize = 13f
                gravity = Gravity.CENTER
                val p = (resources.displayMetrics.density * 4).toInt()
                val v = (resources.displayMetrics.density * 10).toInt()
                setPadding(p, v, p, v)
                setOnClickListener { toggleCategory(key) }
            }
            catChips[key] = chip
            val row = if (i < 4) chipsRow1 else chipsRow2
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            val m = (resources.displayMetrics.density * 3).toInt()
            lp.setMargins(m, m, m, m)
            row.addView(chip, lp)
        }
        catBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(chipsRow1)
            addView(chipsRow2)
            addView(catLabel)
        }
        container.addView(catBar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        container.addView(candidateBar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        container.addView(kv, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        clipPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        container.addView(clipPanel, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        refresh()
        return container
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        if (::clipPanel.isInitialized && clipPanel.visibility == View.VISIBLE) hideClipPanel()
        if (!restarting) {
            val def = if (prefs.getInt("default_lang", 0) == 0) Page.AR else Page.FR
            if (page == Page.AR || page == Page.FR) { page = def; lastAlpha = def }
        }
        refresh()
    }

    override fun onCreateCandidatesView(): View? = null

    // ---------------- themes / helpers ----------------

    private fun theme(): Int = prefs.getInt("theme", 1)
    private fun soundOn(): Boolean = prefs.getBoolean("sound", true)

    private fun haptic() {
        if (!prefs.getBoolean("vibrate", true)) return
        val v = getSystemService(VIBRATOR_SERVICE) as? Vibrator
        v?.vibrate(15)
    }

    private fun clickSound() {
        if (!soundOn()) return
        val am = getSystemService(AUDIO_SERVICE) as? AudioManager
        am?.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, 0.6f)
    }

    private fun specs(s: String) = s.trim().split(Regex("\\s+")).map { KeySpec(it, it) }

    // "ض:١ ص:٢" -> keys with small corner hints (numbers / alternate letters)
    private fun specsH(s: String) = s.trim().split(Regex("\\s+")).map {
        val p = it.split(":")
        KeySpec(p[0], p[0], 1f, if (p.size > 1) p[1] else "")
    }

    // ----- dynamic Enter/Send key (like iPhone) -----
    private fun enterAction(): Int {
        val ei = currentInputEditorInfo ?: return EditorInfo.IME_ACTION_NONE
        if (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION != 0)
            return EditorInfo.IME_ACTION_NONE
        return ei.imeOptions and EditorInfo.IME_MASK_ACTION
    }

    private fun enterLabel(): String = when (enterAction()) {
        EditorInfo.IME_ACTION_SEND   -> "إرسال ➤"
        EditorInfo.IME_ACTION_SEARCH -> "بحث 🔍"
        EditorInfo.IME_ACTION_GO     -> "انتقال ➤"
        EditorInfo.IME_ACTION_DONE   -> "تم ✓"
        EditorInfo.IME_ACTION_NEXT   -> "التالي ➸"
        else -> "⏎"
    }

    private fun rowsFor(p: Page): List<List<KeySpec>> = when (p) {
        Page.AR -> listOf(
            specsH("ض:١ ص:٢ ث:٣ ق:٤ ف:٥ غ:٦ ع:٧ ه:٨ خ:٩ ح:٠ ج:@ د"),
            specsH("ش س ي ب ل:لا ا:أ ت ن م ك ط"),
            listOf(KeySpec("⇧", "@SHIFT", 1.7f)) + specsH("ئ:إ ء:أ ؤ:ئ ر ى:ي ة:ه و:ؤ ز ظ") +
                listOf(KeySpec("⌫", "@DEL", 1.7f)),
            listOf(KeySpec("123", "@NUM", 1.5f), KeySpec("🌐", "@LANG", 1.2f),
                KeySpec("ع", "@SPACE", 4.6f), KeySpec("😊", "@EMOJI", 1.2f),
                KeySpec("🎯", "@CAT", 1.1f), KeySpec(enterLabel(), "@ENTER", 1.9f))
        )
        Page.FR -> listOf(
            specsH("a:1 z:2 e:3 r:4 t:5 y:6 u:7 i:8 o:9 p:0"),
            specs("q s d f g h j k l m"),
            listOf(KeySpec("⇧", "@SHIFT", 1.7f)) + specsH("w x c:ç v b n:ñ") +
                listOf(KeySpec("⌫", "@DEL", 1.7f)),
            listOf(KeySpec("123", "@NUM", 1.5f), KeySpec("🌐", "@LANG", 1.2f),
                KeySpec("En", "@SPACE", 4.6f), KeySpec("😊", "@EMOJI", 1.2f),
                KeySpec("🎯", "@CAT", 1.1f), KeySpec(enterLabel(), "@ENTER", 1.9f))
        )
        Page.NUM -> listOf(
            specs("1 2 3 4 5 6 7 8 9 0"),
            specs("- / : ; ( ) € & @ \""),
            listOf(KeySpec("#+=", "@SYM", 1.6f)) + specs(". , ? ! ' ٪") +
                listOf(KeySpec("⌫", "@DEL", 1.6f)),
            listOf(KeySpec("أبجد", "@ABC", 1.4f), KeySpec("🌐", "@LANG", 1.1f),
                KeySpec("مسافة", "@SPACE", 3.6f), KeySpec("🔢", "@NUMPAD", 1.1f),
                KeySpec("🎯", "@CAT", 1f), KeySpec(enterLabel(), "@ENTER", 1.9f))
        )
        Page.NUMPAD -> listOf(
            listOf(KeySpec(".", ".", 0.55f)) + specs("1 2 3") +
                listOf(KeySpec("⌫", "@DEL", 1.1f)),
            listOf(KeySpec("+", "+", 0.55f)) + specs("4 5 6") +
                listOf(KeySpec("@", "@", 1.1f)),
            listOf(KeySpec("/", "/", 0.55f)) + specs("7 8 9") +
                listOf(KeySpec(enterLabel(), "@ENTER", 1.1f)),
            listOf(KeySpec("-", "-", 0.55f), KeySpec("🌐", "@LANG", 1f),
                KeySpec("0", "0", 2.3f), KeySpec("٪؟!", "@PUNCT", 1.2f),
                KeySpec("أبجد", "@ABC", 1.3f))
        )
        Page.SYM -> listOf(
            specs("~ ` | • √ π ÷ × §"),
            specs("_ ^ [ ] { } ¶ £ ¥"),
            listOf(KeySpec("123", "@NUM", 1.6f)) + specs("© ® ™ ° № < >") +
                listOf(KeySpec("⌫", "@DEL", 1.6f)),
            listOf(KeySpec("أبجد", "@ABC", 1.5f), KeySpec("🌐", "@LANG", 1.2f),
                KeySpec("مسافة", "@SPACE", 4.6f), KeySpec("😊", "@EMOJI", 1.2f),
                KeySpec("🎯", "@CAT", 1.1f), KeySpec(enterLabel(), "@ENTER", 1.9f))
        )
        Page.EMOJI -> listOf(
            specs("😀 😂 🤣 😊 😍 😘 😜 🤪"),
            specs("😎 😢 😡 👍 👎 🙏 👏 💪"),
            specs("❤️ 🔥 ✨ 🎉 🌹 🍀 ☀️ 🌙"),
            specs("🐱 🐶 ⚽ 🎮 🚗 ✈️ 🎵 📱") +
                listOf(KeySpec("⌫", "@DEL", 1.0f)),
            listOf(KeySpec("أبجد", "@ABC", 1.5f), KeySpec("🌐", "@LANG", 1.2f),
                KeySpec("مسافة", "@SPACE", 4.6f), KeySpec("😊", "@EMOJI", 1.2f),
                KeySpec("⚙", "@SET", 1.5f))
        )
    }

    private fun refresh() {
        val c = colors()
        catLabel.setTextColor(c.third)
        updateCatUI()
        kv.shiftActive = shift
        kv.capsActive = capsLock
        kv.showHints = prefs.getBoolean("hints", true)
        kv.applyTheme(theme())
        kv.rows = rowsFor(page)
        container.setBackgroundColor(Themes.get(theme()).bg)
        if (clipPanel.visibility == View.VISIBLE) rebuildClipPanel()
        updateCandidates()
    }

    // ---------------- keyboard view listener ----------------

    private fun separate(): Boolean = prefs.getBoolean("separate", false)

    // ----- spelling game: pick one or more categories, type a letter, word is sent -----
    private lateinit var catBar: LinearLayout
    private lateinit var catLabel: TextView
    private val catChips = linkedMapOf<String, TextView>()
    private val selectedCats = mutableSetOf<String>()

    private val catNames = linkedMapOf(
        "boy" to "👦 ولد", "girl" to "👧 بنت", "thing" to "🪨 جماد", "animal" to "🦁 حيوان",
        "plant" to "🌱 نبات", "country" to "🌍 دولة", "capital" to "🏛️ عاصمة"
    )

    private val catData = mapOf(
        "boy" to mapOf('ا' to "أحمد",'ب' to "بلال",'ت' to "توفيق",'ث' to "ثابت",'ج' to "جمال",
            'ح' to "حسن",'خ' to "خالد",'د' to "داود",'ذ' to "ذو الفقار",'ر' to "ريان",
            'ز' to "زيد",'س' to "سعيد",'ش' to "شكيب",'ص' to "صهيب",'ض' to "ضياء",
            'ط' to "طه",'ظ' to "ظافر",'ع' to "عمر",'غ' to "غسان",'ف' to "فهد",
            'ق' to "قيس",'ك' to "كريم",'ل' to "ليث",'م' to "محمد",'ن' to "نبيل",
            'ه' to "هشام",'و' to "وليد",'ي' to "يوسف"),
        "girl" to mapOf('ا' to "أسماء",'ب' to "بشرى",'ت' to "تقى",'ث' to "ثريا",'ج' to "جنان",
            'ح' to "حنان",'خ' to "خديجة",'د' to "دانة",'ذ' to "ذكرى",'ر' to "رجاء",
            'ز' to "زينب",'س' to "سلمى",'ش' to "شيماء",'ص' to "صفاء",'ض' to "ضحى",
            'ط' to "طيبة",'ظ' to "ظبية",'ع' to "عائشة",'غ' to "غالية",'ف' to "فاطمة",
            'ق' to "قمر",'ك' to "كوثر",'ل' to "لبنى",'م' to "مريم",'ن' to "نادية",
            'ه' to "هدى",'و' to "وجدان",'ي' to "ياسمين"),
        "animal" to mapOf('ا' to "أسد",'ب' to "بقرة",'ت' to "تمساح",'ث' to "ثعلب",'ج' to "جمل",
            'ح' to "حصان",'خ' to "خروف",'د' to "دب",'ذ' to "ذباب",'ر' to "راكون",
            'ز' to "زرافة",'س' to "سمكة",'ش' to "شبل",'ص' to "صقر",'ض' to "ضفدع",
            'ط' to "طاووس",'ظ' to "ظبي",'ع' to "عصفور",'غ' to "غزال",'ف' to "فيل",
            'ق' to "قنفذ",'ك' to "كنغر",'ل' to "لاما",'م' to "ماعز",'ن' to "نمر",
            'ه' to "هدهد",'و' to "وعل",'ي' to "يمام"),
        "thing" to mapOf('ا' to "إبرة",'ب' to "بيت",'ت' to "تلفاز",'ث' to "ثلاجة",'ج' to "جرس",
            'ح' to "حقيبة",'خ' to "خاتم",'د' to "دراجة",'ذ' to "ذهب",'ر' to "راديو",
            'ز' to "زجاجة",'س' to "سرير",'ش' to "شمسية",'ص' to "صابون",'ض' to "ضوء",
            'ط' to "طاولة",'ظ' to "ظرف",'ع' to "عجلة",'غ' to "غطاء",'ف' to "فرشاة",
            'ق' to "قلم",'ك' to "كرسي",'ل' to "لوح",'م' to "مفتاح",'ن' to "نظارة",
            'ه' to "هاتف",'و' to "ورق",'ي' to "ياقوت"),
        "plant" to mapOf('ا' to "أرز",'ب' to "برتقال",'ت' to "تين",'ث' to "ثوم",'ج' to "جزرة",
            'ح' to "حلبة",'خ' to "خيار",'د' to "دفلة",'ذ' to "ذرة",'ر' to "ريحان",
            'ز' to "زيتون",'س' to "سبانخ",'ش' to "شبت",'ص' to "صبار",'ض' to "ضرم",
            'ط' to "طماطم",'ع' to "عنب",'غ' to "غار",'ف' to "فراولة",'ق' to "قصب",
            'ك' to "كزبرة",'ل' to "ليمون",'م' to "موز",'ن' to "نعناع",'ه' to "هليون",
            'و' to "وردة",'ي' to "يقطين"),
        "country" to mapOf('ا' to "إثيوبيا",'ب' to "البحرين",'ت' to "تونس",'ج' to "جيبوتي",
            'د' to "دومينيكا",'ر' to "روسيا",'ز' to "زيمبابوي",'س' to "سوريا",
            'ع' to "عمان",'غ' to "غانا",'ف' to "فرنسا",'ق' to "قطر",
            'ك' to "كندا",'ل' to "ليبيا",'م' to "مالي",'ن' to "نيجيريا",'ه' to "هولندا"),
        "capital" to mapOf('ا' to "أبوظبي",'ب' to "بغداد",'ت' to "طرابلس",'ج' to "الجزائر",
            'د' to "دمشق",'ر' to "ريغا",'ز' to "زغرب",'س' to "سكوبيه",
            'ص' to "صنعاء",'ط' to "طهران",'ع' to "عمان",'ف' to "فادوز",
            'ك' to "كابول",'ل' to "لندن",'م' to "مسقط",'ن' to "نيامي",
            'ه' to "هراري",'و' to "واشنطن",'ي' to "يريفان")
    )

    private fun normalizeArabic(c: Char): Char = when (c) {
        'أ', 'إ', 'آ' -> 'ا'
        'ؤ' -> 'و'
        'ئ' -> 'ي'
        'ى' -> 'ي'
        'ة' -> 'ه'
        else -> c
    }

    // ----- shortcuts: type trigger + space => expansion -----
    private fun loadShortcuts(): Map<String, String> {
        val raw = prefs.getStringSet("shortcuts", null) ?: run {
            val def = mutableSetOf(
                "سلام=السلام عليكم ورحمة الله وبركاته",
                "وعليكم=وعليكم السلام ورحمة الله وبركاته",
                "مع السلامة=مع السلامة، إلى اللقاء 👋",
                "شكرا=شكراً جزيلاً 🌹",
                "عافاك=بارك الله فيك 🙏",
                "ان شاء الله=إن شاء الله 🤲",
                "صباح الخير=صباح الخير 🌅",
                "مساء الخير=مساء الخير 🌙",
                "بريدي=example@gmail.com",
                "tel=0612345678",
                "adr=المغرب")
            prefs.edit().putStringSet("shortcuts", def).apply()
            def
        }
        return raw.associate {
            val i = it.indexOf('=')
            it.substring(0, i) to it.substring(i + 1)
        }
    }

    private fun tryExpand(): Boolean {
        val ic = currentInputConnection ?: return false
        val w = currentWord()
        val exp = loadShortcuts()[w] ?: return false
        ic.deleteSurroundingText(w.length, 0)
        ic.commitText("$exp ", 1)
        return true
    }

    override fun onText(t: String) {
        haptic(); clickSound()
        val ic = currentInputConnection ?: return

        // spelling game: user picked one or more categories, now types a letter
        if (selectedCats.isNotEmpty() && t.length == 1 && t[0].isLetter()) {
            val letter = normalizeArabic(t[0])
            ic.deleteSurroundingText(1, 0) // remove the typed letter
            var found = false
            for ((catKey, _) in catNames) { // search in display order
                if (catKey !in selectedCats) continue
                val word = catData[catKey]?.get(letter)
                if (word != null) {
                    ic.commitText("$word ", 1)  // word sent automatically ✅
                    catLabel.visibility = View.VISIBLE
                    catLabel.text = "✅ ${catNames[catKey]}: $word"
                    found = true
                    break
                }
            }
            if (!found) {
                catLabel.visibility = View.VISIBLE
                catLabel.text = "😅 لا توجد كلمة بحرف «$t» في الأقسام المختارة — جرّب حرفاً آخر"
            }
            updateCandidates()
            return
        }

        // separated spelling mode: ا ح م د — insert a space after each letter
        val out = if (separate() && t.length == 1 && t[0].isLetter()) "$t " else t
        ic.commitText(out, 1)
        if (!capsLock) shift = false
        kv.shiftActive = shift; kv.capsActive = capsLock
        kv.invalidate()
        updateCandidates()
    }

    override fun onSpecial(token: String) {
        val ic = currentInputConnection ?: return
        when (token) {
            "@DEL" -> { haptic(); ic.deleteSurroundingText(1, 0); updateCandidates() }
            "@DEL_WORD" -> { haptic(); deleteWord(); updateCandidates() }
            "@DEL_ALL" -> {
                haptic()
                val before = ic.getTextBeforeCursor(4096, 0)?.length ?: 0
                val after = ic.getTextAfterCursor(4096, 0)?.length ?: 0
                ic.deleteSurroundingText(before, after)
                updateCandidates()
            }
            "@SPACE" -> {
                haptic(); clickSound()
                if (tryExpand()) { updateCandidates(); return }
                learnWord()
                // in separated mode avoid double spaces: drop the auto space first
                if (separate() && ic.getTextBeforeCursor(1, 0)?.toString() == " ")
                    ic.deleteSurroundingText(1, 0)
                ic.commitText(" ", 1); updateCandidates()
            }
            "@ENTER" -> {
                haptic(); clickSound()
                if (tryExpand()) { updateCandidates(); return }
                learnWord()
                val action = enterAction()
                if (action != EditorInfo.IME_ACTION_NONE) ic.performEditorAction(action)
                else ic.commitText("\n", 1)
                updateCandidates()
            }
            "@SHIFT" -> {
                when {
                    capsLock -> { capsLock = false; shift = false }
                    shift -> { shift = false; capsLock = true }
                    else -> shift = true
                }
                refresh()
            }
            "@LANG" -> {
                page = if (page == Page.AR) Page.FR else if (page == Page.FR) Page.AR else lastAlpha
                if (page == Page.AR || page == Page.FR) lastAlpha = page
                shift = false; capsLock = false
                refresh()
            }
            "@CAT" -> {
                if (catBar.visibility == View.VISIBLE) {
                    catBar.visibility = View.GONE
                    selectedCats.clear()
                    catLabel.visibility = View.GONE
                } else {
                    catBar.visibility = View.VISIBLE
                    updateCatUI()
                }
            }
            "@NUM" -> { page = Page.NUM; refresh() }
            "@NUMPAD" -> { page = Page.NUMPAD; refresh() }
            "@PUNCT" -> { ic.commitText("٪", 1) }
            "@SYM" -> { page = Page.SYM; refresh() }
            "@ABC" -> {
                page = if (page == Page.NUMPAD) Page.NUM else lastAlpha
                refresh()
            }
            "@EMOJI" -> { page = Page.EMOJI; refresh() }
            "@SET" -> {
                // open the settings panel (like iPhone's keyboard settings)
                val intent = android.content.Intent(this, SettingsActivity::class.java)
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { startActivity(intent) }
            }
            "@SET_LONG" -> {
                // quick theme cycle without leaving the keyboard
                val t2 = (theme() + 1) % Themes.COUNT
                prefs.edit().putInt("theme", t2).apply()
                refresh()
            }
        }
    }

    // ---------------- spelling-game selection ----------------

    private fun toggleCategory(key: String) {
        haptic()
        if (key == ALL_KEY) {
            if (selectedCats.size == catNames.size) selectedCats.clear()
            else selectedCats.addAll(catNames.keys)
        } else {
            if (key in selectedCats) selectedCats.remove(key)
            else selectedCats.add(key)
        }
        updateCatUI()
    }

    private fun updateCatUI() {
        val c = colors()
        for ((key, chip) in catChips) {
            val on = if (key == ALL_KEY) selectedCats.size == catNames.size else key in selectedCats
            chip.setTextColor(if (on) c.third else c.second)
            chip.paint.isFakeBoldText = on
            chip.alpha = if (on) 1.0f else 0.75f
        }
        if (selectedCats.isEmpty()) {
            catLabel.visibility = View.GONE
        } else {
            catLabel.visibility = View.VISIBLE
            val names = catNames.filterKeys { it in selectedCats }.values
            catLabel.text = "🎯 اكتب الحرف:  " + names.joinToString(" + ")
        }
    }

    private fun deleteWord() {
        val ic = currentInputConnection ?: return
        val t = ic.getTextBeforeCursor(32, 0) ?: return
        var n = 0
        var i = t.length
        while (i > 0 && t[i - 1] == ' ') { i--; n++ }
        while (i > 0 && (t[i - 1].isLetterOrDigit() || t[i - 1] == '\'')) { i--; n++ }
        ic.deleteSurroundingText(n.coerceAtLeast(1), 0)
    }

    // ---------------- suggestions & learning ----------------

    private fun currentWord(): String {
        val ic = currentInputConnection ?: return ""
        val t = ic.getTextBeforeCursor(32, 0) ?: return ""
        val m = Regex("[\\p{L}\\p{N}']+$").find(t) ?: return ""
        return m.value
    }

    private fun suggest(prefix: String): List<String> {
        if (prefix.length < 2) return emptyList()
        val base = if (page == Page.FR) frWords else arWords
        val learned = prefs.getStringSet("learned", emptySet())!!.toList()
        val scored = mutableListOf<Pair<Int, String>>()
        for (w in (base + learned).distinct()) {
            if (w == prefix) continue
            if (!w.startsWith(prefix, ignoreCase = true)) continue
            val score = prefs.getInt("f_$w", 1) * 10 + w.length.coerceAtMost(9)
            scored.add(score to w)
        }
        return scored.sortedByDescending { it.first }.take(3).map { it.second }
    }

    private fun learnWord() {
        // in separated mode the "word" is one letter — skip learning
        if (separate()) return
        val w = currentWord().lowercase(Locale.ROOT)
        if (w.length < 2) return
        val set = prefs.getStringSet("learned", emptySet())!!.toMutableSet()
        if (set.size < 400) set.add(w)
        prefs.edit().putStringSet("learned", set)
            .putInt("f_$w", prefs.getInt("f_$w", 0) + 1).apply()
    }

    private fun updateCandidates() {
        candidateBar.removeAllViews()
        val p = Themes.get(theme())
        candidateBar.setBackgroundColor(p.bg)
        candidateBar.gravity = Gravity.CENTER_VERTICAL
        candidateBar.setPadding(dp(4), dp(4), dp(4), dp(2))

        // fixed tools: clipboard + settings (long press on ⚙ = quick theme switch)
        if (clipEnabled()) {
            candidateBar.addView(pillView("📋", p.key, p.text) { toggleClipPanel() },
                LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(2), 0, dp(3), 0) })
        }
        val gear = pillView("⚙", p.key, p.special) { onSpecial("@SET") }
        gear.setOnLongClickListener { onSpecial("@SET_LONG"); true }
        candidateBar.addView(gear,
            LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(2), 0, dp(4), 0) })

        val scroller = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        scroller.addView(inner)
        fun chip(text: String, bold: Boolean, onClick: () -> Unit) {
            val tv = pillView(text, p.key, if (bold) p.special else p.text, 16f, onClick)
            inner.addView(tv,
                LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(3), 0, dp(3), 0) })
        }

        // a clip copied in the last 2 minutes is offered for quick paste
        if (clipEnabled() && currentWord().isEmpty()) {
            val last = clipStore.latest()
            if (last != null && last.time != dismissedClipTime &&
                System.currentTimeMillis() - last.time < 120_000L) {
                val flat = last.text.replace("\n", " ").trim()
                val shown = if (flat.length > 16) flat.take(16) + "…" else flat
                chip("📋 $shown", true) {
                    currentInputConnection?.commitText(last.text, 1)
                    dismissedClipTime = last.time
                    updateCandidates()
                }
            }
        }

        for (s in suggest(currentWord())) chip(s, true) { applySuggestion(s) }
        val ic = currentInputConnection
        if (ic != null) chip("✓", false) { learnWord(); ic.commitText(" ", 1); updateCandidates() }
        candidateBar.addView(scroller, LinearLayout.LayoutParams(0, WRAP, 1f))
    }

    private fun applySuggestion(sug: String) {
        val ic = currentInputConnection ?: return
        val w = currentWord()
        ic.deleteSurroundingText(w.length, 0)
        ic.commitText(sug + " ", 1)
        prefs.edit().putInt("f_$sug", prefs.getInt("f_$sug", 0) + 3).apply()
        updateCandidates()
    }

    private fun colors(): Triple<Int, Int, Int> {
        val p = Themes.get(theme())
        return Triple(p.bg, p.text, p.special)
    }

    // ---------------- clipboard ----------------

    private lateinit var clipPanel: LinearLayout
    private lateinit var clipManager: ClipboardManager
    private lateinit var clipStore: ClipboardStore
    private var dismissedClipTime = 0L
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip() }

    private fun clipEnabled(): Boolean = prefs.getBoolean("clip_enabled", true)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundBg(fill: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun pillView(text: String, bg: Int, fg: Int, sizeSp: Float = 15f,
                         onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = sizeSp
        setTextColor(fg)
        gravity = Gravity.CENTER
        background = roundBg(bg, 12)
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setOnClickListener { onClick() }
    }

    private fun captureClip() {
        if (!clipEnabled()) return
        val clip = clipManager.primaryClip ?: return
        if (clip.itemCount == 0) return
        // skip content apps mark as sensitive (passwords, OTP, ...)
        val sensitive = clip.description?.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false)
        if (sensitive == true) return
        val text = clip.getItemAt(0).coerceToText(this)?.toString() ?: return
        clipStore.add(text)
        if (::candidateBar.isInitialized) updateCandidates()
        if (::clipPanel.isInitialized && clipPanel.visibility == View.VISIBLE) rebuildClipPanel()
    }

    private fun showClipPanel() {
        val h = maxOf(kv.height, dp(216))
        clipPanel.layoutParams = LinearLayout.LayoutParams(MATCH, h)
        rebuildClipPanel()
        kv.visibility = View.GONE
        clipPanel.visibility = View.VISIBLE
    }

    private fun hideClipPanel() {
        clipPanel.visibility = View.GONE
        kv.visibility = View.VISIBLE
    }

    private fun toggleClipPanel() {
        haptic()
        if (clipPanel.visibility == View.VISIBLE) hideClipPanel() else showClipPanel()
    }

    private fun rebuildClipPanel() {
        val p = Themes.get(theme())
        clipPanel.removeAllViews()
        clipPanel.setBackgroundColor(p.bg)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(4))
        }
        header.addView(TextView(this).apply {
            text = "📋 الحافظة"
            textSize = 16f
            setTextColor(p.special)
            paint.isFakeBoldText = true
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(pillView("🗑 مسح", p.key, p.text, 13f) {
            clipStore.clearUnpinned(); rebuildClipPanel()
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(4), 0, dp(4), 0) })
        header.addView(pillView("⌨ رجوع", p.enterBg, p.enterText, 13f) { hideClipPanel() })
        clipPanel.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val items = clipStore.displayList()
        if (items.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "لا يوجد شيء بعد 📭\nانسخ أي نص وسيظهر هنا تلقائياً"
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(p.hint)
                setPadding(dp(16), dp(28), dp(16), dp(28))
            }, LinearLayout.LayoutParams(MATCH, WRAP))
        } else {
            for (item in items) {
                list.addView(clipRow(item, p), LinearLayout.LayoutParams(MATCH, WRAP).apply {
                    setMargins(dp(8), dp(3), dp(8), dp(3))
                })
            }
        }
        val scroll = ScrollView(this)
        scroll.addView(list)
        clipPanel.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    private fun iconBtn(text: String, a: Float, p: Palette, onClick: () -> Unit): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 16f
            gravity = Gravity.CENTER
            alpha = a
            setTextColor(p.text)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnClickListener { onClick() }
        }

    private fun clipRow(item: ClipItem, p: Palette): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tv = TextView(this).apply {
            text = item.text.trim()
            textSize = 15f
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(p.text)
            background = roundBg(p.key, 12)
            setPadding(dp(12), dp(9), dp(12), dp(9))
            setOnClickListener {
                haptic(); clickSound()
                currentInputConnection?.commitText(item.text, 1)
                hideClipPanel()
                updateCandidates()
            }
        }
        row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(iconBtn("📌", if (item.pinned) 1f else 0.3f, p) {
            haptic(); clipStore.togglePin(item.text); rebuildClipPanel()
        })
        row.addView(iconBtn("✕", 0.7f, p) {
            haptic(); clipStore.remove(item.text); rebuildClipPanel()
        })
        return row
    }

    companion object {
        private const val ALL_KEY = "all"
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    }
}
